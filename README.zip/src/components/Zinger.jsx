import React from 'react'

export const Zinger = () => {
  return (
    <><h2>Zinger Burger</h2>
    
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odio, error molestias ratione quam accusamus itaque, nesciunt aliquam assumenda earum ipsam ipsum exercitationem suscipit! Hic, saepe amet. Odio saepe assumenda blanditiis?</p>
    
    </>
  )
}
