import React from 'react'




export const Team = () => {
  return (
    <>
    
    <section id="team" class="team section-bg">
      <div class="container" >

        <div class="section-title">
          <h2>Team</h2>
          <p>Every IT team is different, based on the culture and needs of its company, 
            the experience and skills of the team members and the types of systems on which 
            they are working.
</p>
        </div>

        <div class="row">


</div>
</div>
</section>  

    </>
  )
}