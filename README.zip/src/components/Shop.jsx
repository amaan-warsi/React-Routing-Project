import React from 'react'

export const Shop = () => {
  return (
    <div><h1>Shop</h1></div>
  )
}
