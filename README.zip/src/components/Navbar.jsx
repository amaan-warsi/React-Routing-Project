import React from 'react'
import { Outlet, Link } from 'react-router-dom'

export const Navbar = () => {
  return (
    <>

<div id="topbar" class="d-flex align-items-center fixed-top">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-phone d-flex align-items-center"><span>+1 5589 55488 55</span></i>
        <i class="bi bi-clock d-flex align-items-center ms-4"><span> Mon-Sat: 11AM - 23PM</span></i>
      </div>
    </div>
  </div>
  <header id="header" class="fixed-top d-flex align-items-cente">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-lg-between">
      <h1 class="logo me-auto me-lg-0"><Link to="/">My Restaurant</Link></h1>
      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><Link class="nav-link scrollto active" to="/">Home</Link></li>
          <li><Link class="nav-link scrollto" to="/aboutus">About</Link></li>
          <li><Link class="nav-link scrollto" to="/menu">Menu</Link></li>
          <li><Link class="nav-link scrollto" to="/specials">Specials</Link></li>
           <li><Link class="nav-link scrollto" to="/gallery">Gallery</Link></li>
           <li><Link class="nav-link scrollto" to="/booking">Book Now</Link></li>
           <li><Link class="nav-link scrollto" to="/contact">Contact</Link></li>
           <li class="dropdown"><Link to="/shop"><span>Shop</span> 
           <i class="bi bi-chevron-down"></i></Link>
            <ul>
              <li><Link to="zinger">Zinger Buger</Link></li>
              <li><Link to="sandwich">Sandwich</Link></li>
              <li><Link to="#">Juice</Link></li>
              </ul>
          </li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <Outlet />
      <Link to="/booking" class="book-a-table-btn scrollto d-none d-lg-flex">Book a table</Link>
    </div>
  </header>
</>
  )
}
