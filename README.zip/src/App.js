import React from 'react'
import { Outlet, Routes, Route } from "react-router-dom";
import { Navbar } from './components/Navbar';
import { Aboutus } from './components/Aboutus';
import { Menu } from './components/Menu';
import { Specials } from './components/Specials';
import { Footer } from './components/Footer';
import { Hero } from './components/Hero';
import Gallery from './components/Gallery';
import { Contact } from './components/Contact';
import { Booking } from './components/Booking';
import { Zinger } from './components/Zinger';
import { Sandwich } from './components/Sandwich';
import { Shop } from './components/Shop';

function App() {
  return (
 <>

      <Navbar />
      <main id="main">

      
      <Routes>
        
      <Route path="/" element={<Hero />} />
      <Route path="aboutus" element={<Aboutus />} /> 
      <Route path="menu" element={<Menu />} />
      <Route path="specials" element={<Specials />} />
      <Route path="gallery" element={<Gallery />} />
      <Route path="contact" element={<Contact />} />
      <Route path="booking" element={<Booking />} />
        <Route Shop element={<Shop />}>
        <Route path="zinger" element={<Zinger />} />
        <Route path="sandwich" element={<Sandwich />} />
      </Route>
      <Route path="*" element={<h1>NO Page Found</h1>} />
      </Routes>
      <Outlet />
 
       <Footer />

        </main>
        
      </> 
 

  );
}

export default App;
