import React from 'react'

export const Sandwich = () => {
  return (
    <div><h1>Sandwich</h1></div>
  )
}
